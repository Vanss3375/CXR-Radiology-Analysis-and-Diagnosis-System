# CXR Nodules Detection > 2024-06-04 12:29am
https://universe.roboflow.com/petra-michael/cxr-nodules-detection

Provided by a Roboflow user
License: CC BY 4.0

