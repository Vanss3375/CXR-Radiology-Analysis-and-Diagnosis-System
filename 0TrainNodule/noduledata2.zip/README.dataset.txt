# CXR Nodules Detection > 2024-05-29 4:57pm
https://universe.roboflow.com/petra-michael/cxr-nodules-detection

Provided by a Roboflow user
License: CC BY 4.0

