# LungDS > LungDS_version_1.0
https://universe.roboflow.com/dhanush-vukln/lungds

Provided by a Roboflow user
License: CC BY 4.0

