# malignant nodules > 2023-02-02 2:26pm
https://universe.roboflow.com/college-kdlgd/malignant-nodules

Provided by a Roboflow user
License: CC BY 4.0

